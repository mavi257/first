Author: CodexWorld
Author URL: http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/delete-multiple-records-from-mysql-in-php/

============ Introduction ============
This project helps web developers to delete records from database in PHP using checkbox.

============ Installation ============
1. Create a database (codexworld) at phpMyAdmin.
2. Import the users.sql file into the database (codexworld).
3. Open the "dbConfig.php" file and modify the $dbHost, $dbUser, $dbPass and $dbName variables value with your MySQL details.
4. Run the index.php file at the browser and test the functionalities.

============ May I Help You ===========
If you have any query about this script, please feel free to comment here - http://www.codexworld.com/delete-multiple-records-from-mysql-in-php/#respond. We will reply your query ASAP.